package com.example.flutter_helloworld

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
